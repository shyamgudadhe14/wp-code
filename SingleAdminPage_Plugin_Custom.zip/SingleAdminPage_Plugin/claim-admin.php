<?php
    global $chk;
    if(isset($_POST['wphw_submit'])){
            wphw_opt();
    }
    function wphw_opt(){
        $hellotxt = $_POST['hello-text'];
        global $chk;
        if( get_option('hello_text') != trim($hellotxt)){
            $chk = update_option( 'hello_text', trim($hellotxt));
        }
    }
?>
<div class="wrap">
  <div id="icon-options-general" class="icon32"> <br>
  </div>
  <h2>Claim Form Listing</h2>
  <?php if(isset($_POST['wphw_submit']) && $chk):?>
  <div id="message" class="updated below-h2">
    <p>Content updated successfully</p>
  </div>
  <?php endif;?>
  <div class="metabox-holder">
          <iframe src="http://trsmoving.com/formadmin/"   height="600" width="1150"></iframe> 
  </div>
</div>