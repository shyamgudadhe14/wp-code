<?php
/*
    Plugin Name: Claim
    Plugin URI: www.aimstechnology.com
    Description: This is plugin for single admin page.
    Version: 1.0.0
    Author: Shyam Gudadhe
    Author URI: www.aimstechnology.com
    License: GPL2
*/
?>

<?php
    function wp_claim_menu(){
        add_menu_page( 'Claim Form Entries', 'Claim Form', 'manage_options', 'claim_form', 'wphw_opt_admin' );
    }
 
    add_action('admin_menu','wp_claim_menu');
 
    function wphw_opt_admin(){
        include_once('claim-admin.php');
    }
?>

<?php
function show_text(){
    echo get_option('hello_text');
}
 
function show_hello_text() {
    return get_option('hello_text');
}
 
add_shortcode('showtext', 'show_hello_text');
?>